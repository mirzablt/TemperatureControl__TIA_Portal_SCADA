﻿/* 
* Copyright (C) Siemens AG 2013.
* All Rights Reserved. Confidential.
*
* @namespace CPM.Lib.ScrollButton
* @desc ScrollButton implementation in SVG.
*
*/
var CPM = ( CPM || {} );
CPM.Lib = ( CPM.Lib || {} );

//scrollbutton styles
//CPM.Lib.scrollbarStyles = { fill: 'whitesmoke', stroke: 'dimgray', 'stroke-width': 1 };
//CPM.Lib.triangleStyles = { fill: 'dimgray' };
//CPM.Lib.highlightStyles = { fill: 'dimgray', stroke: 'dimgray', 'stroke-width': 1 };

CPM.Lib.scrollbarStyles = { fill: 'rgba(240, 240, 254, 1)' };
CPM.Lib.triangleStyles = { fill: 'rgba(100, 100, 106, 0.5)' };
// CPM.Lib.triangleStyles = { fill: 'none', stroke: '#CCCCCC', 'stroke-width': 2 };
CPM.Lib.highlightStyles = { fill: '#BBBBBB' };
CPM.Lib.buttonDisabledStyles = { fill: '#F6F6F6' };


//id,parentNode,x,y,width,height,scrollButtonOrientation,functionToCall
CPM.Lib.ScrollButton = function ( id, parentNode, x, y, width, height, scrollButtonOrientation, functionToCall ) {

    'use strict';

    // PRIVATE API
    var
    _id = id,
    _scrollButtonOrientation = scrollButtonOrientation,
    _scrollbarStyles = CPM.Lib.scrollbarStyles,
    _triangleStyles = CPM.Lib.triangleStyles,
    _highlightStyles = CPM.Lib.highlightStyles,
    _disabledStyles = CPM.Lib.buttonDisabledStyles,
    _functionToCall = functionToCall,
    //additional properties to be used later
    _parentGroup = null,
    _scrollRect = null,
    _scrollTriangle = null,

    //test if parent group exists or create a new group at the end of the file
    _testParent = function ( parentNode ) {
        //test if of type object
        var nodeValid = false;
        _parentGroup = CPM.svgUtil.createSVG( 'g' );
        if ( typeof ( parentNode ) === 'object' ) {
            if ( parentNode.nodeName === 'svg' || parentNode.nodeName === 'g' || parentNode.nodeName === 'svg:svg' || parentNode.nodeName === 'svg:g' ) {
                parentNode.appendChild( _parentGroup );
                nodeValid = true;
            }
        }
        else if ( typeof ( parentNode ) === 'string' ) {
            //first test if button group exists
            if ( !document.getElementById( parentNode ) ) {
                _parentGroup.setAttributeNS( null, 'id', parentNode );
                document.documentElement.appendChild( _parentGroup );
                nodeValid = true;
            }
            else {
                document.getElementById( parentNode ).appendChild( _parentGroup );
                nodeValid = true;
            }
        }
        return nodeValid;
    },

    //create scrollbutton geometry
    _createScrollbutton = function ( x, y, width, height ) {
        var myTriPath, triangleFourth, attrib,
            cellHeight, offsY = 0, offsX = 0, dataTifType;

        if ( height > width ) {
            offsY = ( height - width ) / 2;
            cellHeight = width;
        }
        else {
            offsX = ( width - height ) / 2;
            cellHeight = height;
        }

        //this is used to construct the triangles for the buttons
        triangleFourth = cellHeight / 4;

        if ( _scrollButtonOrientation === 'vertical_up' ) {
            dataTifType = 'LineUp';
            myTriPath = 'M' + ( x + triangleFourth ) + ' ' + ( y + offsY + 3 * triangleFourth ) +
                ' L' + ( x + cellHeight * 0.5 ) + ' ' + ( y + offsY + triangleFourth ) +
                ' L' + ( x + 3 * triangleFourth ) + ' ' + ( y + offsY + 3 * triangleFourth ) + ' Z';
        }
        else if ( _scrollButtonOrientation === 'vertical_down' ) {
            dataTifType = 'LineDown';
            myTriPath = 'M' + ( x + triangleFourth * 3 ) + ' ' + ( y + offsY + triangleFourth ) +
                ' L' + ( x + cellHeight * 0.5 ) + ' ' + ( y + offsY + 3 * triangleFourth ) +
                ' L' + ( x + triangleFourth ) + ' ' + ( y + offsY + triangleFourth ) + ' Z';
        }
        else if ( _scrollButtonOrientation === 'horizontal_up' ) {
            dataTifType = 'LineUp';
            myTriPath = 'M' + ( x + triangleFourth ) + ' ' + ( y + triangleFourth * 2 ) +
                ' L' + ( x + 3 * triangleFourth ) + ' ' + ( y + 3 * triangleFourth ) +
                ' L' + ( x + 3 * triangleFourth ) + ' ' + ( y + triangleFourth ) + ' Z';
        }
        else {
            dataTifType = 'LineDown';
            myTriPath = 'M' + ( x + triangleFourth * 3 ) + ' ' + ( y + 2 * triangleFourth ) +
                ' L' + ( x + triangleFourth ) + ' ' + ( y + triangleFourth ) +
                ' L' + ( x + triangleFourth ) + ' ' + ( y + triangleFourth * 3 ) + ' Z';
        }

        // rect
        _scrollRect = CPM.svgUtil.createSVG( 'rect', {
            id: _id,
            'data-tif-type': dataTifType,
            x: x,
            y: y,
            width: width,
            height: height,
	    'fill-opacity':0,
            appendTo: _parentGroup
        } );
        for ( attrib in _scrollbarStyles ) {
            _scrollRect.setAttributeNS( null, attrib, _scrollbarStyles[attrib] );
        }

        // triangle
        _scrollTriangle = CPM.svgUtil.createSVG( 'path', {
            d: myTriPath,
            'pointer-events': 'none',
            appendTo: _parentGroup
        } );
        for ( attrib in _triangleStyles ) {
            _scrollTriangle.setAttributeNS( null, attrib, _triangleStyles[attrib] );
        }
    };

    // INITIALIZER
    ( function () {
        //create scrollbar
        if ( _testParent( parentNode ) ) {
            _createScrollbutton( x, y, width, height );
        }
    } )();

    // PUBLIC API
    return {
        onPointerDown: function ( x, y, target ) {
            var attrib;

            //change appearance of button
            //for ( attrib in _scrollerStyles ) {
            //    _scrollButton.removeAttributeNS( null, attrib );
            //}
            //for ( attrib in _highlightStyles ) {
            //    _scrollButton.setAttributeNS( null, attrib, _highlightStyles[attrib] );
            //}
            //change appearance of triangle
            for ( attrib in _triangleStyles ) {
                _scrollTriangle.removeAttributeNS( null, attrib );
            }
            for ( attrib in _highlightStyles ) {
                _scrollTriangle.setAttributeNS( null, attrib, _highlightStyles[attrib] );
            }

            this.fireFunction( 'buttonDown' );
        },

        onPointerUp: function ( x, y ) {
            var attrib;

            //change appearance of button
            //for ( attrib in _highlightStyles ) {
            //    _scrollButton.removeAttributeNS( null, attrib );
            //}
            //for ( attrib in _scrollerStyles ) {
            //    _scrollButton.setAttributeNS( null, attrib, _scrollerStyles[attrib] );
            //}
            //change appearance of triangle
            for ( attrib in _highlightStyles ) {
                _scrollTriangle.removeAttributeNS( null, attrib );
            }
            for ( attrib in _triangleStyles ) {
                _scrollTriangle.setAttributeNS( null, attrib, _triangleStyles[attrib] );
            }

            this.fireFunction( 'buttonUp' );
        },

        fireFunction: function ( changeType ) {
            if ( typeof ( _functionToCall ) === 'function' ) {
                _functionToCall( _id, changeType );
                return;
            }
            if ( typeof ( _functionToCall ) === 'object' ) {
                _functionToCall.scrollbuttonChanged( _id, changeType );
                return;
            }
        },

        updateScrollButton: function ( x, y, width, height ) {
            var myTriPath, triangleFourth, cellHeight, offsY = 0, offsX = 0,
                setAttributes = CPM.svgUtil.setAttr;

            if ( height > width ) {
                offsY = ( height - width ) / 2;
                cellHeight = width;
            }
            else {
                offsX = ( width - height ) / 2;
                cellHeight = height;
            }

            //this is used to construct the triangles for the buttons
            triangleFourth = cellHeight / 4;

            if ( _scrollButtonOrientation === 'vertical_up' ) {
                myTriPath = 'M' + ( x + triangleFourth ) + ' ' + ( y + offsY + 3 * triangleFourth ) +
                ' L' + ( x + cellHeight * 0.5 ) + ' ' + ( y + offsY + triangleFourth ) +
                ' L' + ( x + 3 * triangleFourth ) + ' ' + ( y + offsY + 3 * triangleFourth ) + ' Z';
            }
            else if ( _scrollButtonOrientation === 'vertical_down' ) {
                myTriPath = 'M' + ( x + triangleFourth * 3 ) + ' ' + ( y + offsY + triangleFourth ) +
                ' L' + ( x + cellHeight * 0.5 ) + ' ' + ( y + offsY + 3 * triangleFourth ) +
                ' L' + ( x + triangleFourth ) + ' ' + ( y + offsY + triangleFourth ) + ' Z';
            }
            else if ( _scrollButtonOrientation === 'horizontal_up' ) {
                myTriPath = 'M' + ( x + triangleFourth ) + ' ' + ( y + triangleFourth * 2 ) +
                ' L' + ( x + 3 * triangleFourth ) + ' ' + ( y + 3 * triangleFourth ) +
                ' L' + ( x + 3 * triangleFourth ) + ' ' + ( y + triangleFourth ) + ' Z';
            }
            else {
                myTriPath = 'M' + ( x + triangleFourth * 3 ) + ' ' + ( y + 2 * triangleFourth ) +
                ' L' + ( x + triangleFourth ) + ' ' + ( y + triangleFourth ) +
                ' L' + ( x + triangleFourth ) + ' ' + ( y + triangleFourth * 3 ) + ' Z';
            }

            // rect
            setAttributes( _scrollRect, {
                x: x,
                y: y,
                width: width,
                height: height
            } );

            // triangle
            setAttributes( _scrollTriangle, {
                d: myTriPath,
                'pointer-events': 'none'
            } );
        },

        hide: function () {
            _parentGroup.setAttributeNS( null, 'display', 'none' );
        },

        show: function () {
            _parentGroup.setAttributeNS( null, 'display', 'inherit' );
        },

        remove: function () {
            _parentGroup.parentNode.removeChild( _parentGroup );
        },

        enable: function () {
            var attrib;
            for ( attrib in _disabledStyles ) {
                _scrollRect.removeAttributeNS( null, attrib );
            }
            for ( attrib in _scrollbarStyles ) {
                _scrollRect.setAttributeNS( null, attrib, _scrollbarStyles[attrib] );
            }
        },

        disable: function () {
            var attrib;
            for ( attrib in _scrollbarStyles ) {
                _scrollRect.removeAttributeNS( null, attrib );
            }
            for ( attrib in _disabledStyles ) {
                _scrollRect.setAttributeNS( null, attrib, _disabledStyles[attrib] );
            }
        },
        updateColor: function () {
            _scrollRect.setAttributeNS( null, 'fill', _scrollbarStyles['fill'] );
        }
    };
};