/**
* Creates an instance of TreeControl
* @class
* @desc Class for creating TreeControl
* @constructor
*/
var CPM = ( CPM || {} );
CPM.App = function () {
    var
    // holds refernce of callback function to be called on event occurs on DOM
    _callback,
    // holds information of general operations
    _operation = {
        add: 'add',
        remove: 'remove'
    },
    // holds left value
    _left = 5,
    // holds top value
    _top = 5,
    _id = 'CPM_Tree_Combo',
    _deepestNode = 0,
    _deepestNodeWidth = 0,
    _prevNodeSelected,
    _ctrlHeight = 0,
    _nodeHeight = 33.5, // Hardcoded value as there is no configuration available for the font for control in ES
    _divParent = null,
    _isExpandAll = false,
    _isFullDataPresent = false,
    _isCollapseAll = false,
    _scrollVerticalHandler = new CPM.Control.ScrollHandler(),
    _scrollBCVerticalHandler = new CPM.Control.ScrollHandler(),
    _scrollHorizontalHandler = new CPM.Control.ScrollHandler(),
    _urlPartTotalHeight,
    _nodeDomHeight,
    _toolbarHeight,
    _isScrollbarCreated = false,
    _isBCVerticalScrollbarCreated = false,
    _isHorizontalScrollbarCreated = false,
    _treeGroup = null,
    _breadcrumbGroup = null,
    _breadcrumbGroupMatrix,
    _deepestIdx = 1,
    _isBreadCrumbCreated = false,
    _prevHoveredNodeId = null,
    _prevSelectedBCNodeId = null,
    _prevSelectedCrumbNode,
    _nodeHandler,
    _treeControlGroup = null,
    _breadCrumb,
    _toolbar,
    _vpNodeCount,
    _scrollCount = 0,
    _linearDataArray = [],
    _bufferDataArray = [],

    _isBCUpdateRequired = false,
    _treeGroupMatrix,
    _vScrollStep = 0,
    _prevScrollPerc = 0,
    _vBCScrollStep = 0,
    _vBCScrollHeight = 0,
    _prevBCScrollPerc = 0,
    _hScrollStep = 0,
    _hScrollWidth = 0,
    //maintain count information. it is used to calculate index of tree nodes
    _count = 0,
    _crumbChildren = [],
    _crumbX,
    _crumbNodeNameWidth,
    _showCrumb = false,
    _crumbHeight,
    _clickedURLNodeId,
    _crumbNodeNameHeight,
    _comboBoxHandler,
    _filterComboBox,
    _scrollbarGrp,
	_options = {},
    self = this,
    // holds font information
    TEXT_BBOX = 0,
    _font = {
        parttype: 'FontPart',
        Size: 14,
        family: 'Siemens Sans',
        color: 'black'
    },
    _data = {
        Left: _left,
        Top: _top,
        Width: 150,
        Height: 900,
        Font: _font,
        NodePart: [],
        URLPart: { border: { height: 25, width: 0, strokeWidth: 1, paddingRight: 10 }, font: { size: 15 }, imageIcon: { width: 20 }, textPadding: { left: 15, right: 7 }, data: [], viewportData: [] },
        ToolbarPart: {
            border: {
                height: 55, width: 50, topVal: 0, strokeWidth: 1, paddingRight: 10, iconSpacing: 7,
                buttonHeight: 36,
                buttonTop: 10
            }, font: { size: 15 }, imageIcon: { width: 24, height: 20 }, textPadding: { left: 5, right: 5 }, data: [], viewportData: []
        }
    },
    _cntrlHeightNew = 0,
    _cntrlWidthNew = 0,
    // holds refernce of svgParent
    _svgParent,
    // holds selectedNode Id
    _selectedNodeId,
    _horizontalInitialScrollOffset = 0,
    _hScrollbarHeight,
     _alarmComapnion,
     _screenWindowCompanion,
     _shcCompanion,
     _selectedNodePath,
     _eventManager,
     _tbUpdateRequired = false,
     _enableExpandBtn = false,
     _alarmData = {},
	 _screenData = {},
     _selectedFilter,
    _createFilter = false,
    _comboMaxWidth,
    _prevComboLeft,
    _addExtraScroll,
    //returns default node properties
    _getDefaultNode = function () {
        return {
            Name: null,
            Id: null,
            ObjectType: null,
            IsExpanded: true,
            IsLeaf: false,
            Visible: true,
            Children: [],
            Parent: WebCC.Properties.SelectedNode,
            ParentId: _selectedNodeId
        };
    },

    //calculates bbox information of text
    _fillBBoxInfo = function ( data ) {
        if ( data ) {
            var text = ( data.name || 'XY' ),
            bbox = CPM.svgUtil.getTextBBox( { Size: _data.URLPart.font.size, Weight: 'bold' }, '' + text );
            data.height = Math.ceil( bbox.height );
            data.width = Math.ceil( bbox.width );
        }
    },

    //returns node data based on nodeId
    _getNodeData = function ( nodeId ) {
        var nodeData,
        nodePart = _data.NodePart[0];
        if ( nodeId === nodePart.Id ) {
            nodeData = nodePart;
        }
        else {
            nodeData = _searchForNode( nodePart, nodeId, _operation.add );
        }
        return nodeData;
    },

    //returns node data based on fullPath
    _getNodeDataByPath = function ( fullPath ) {
        var nodeData,
        nodePart = _data.NodePart[0];
        if ( nodePart ) {
            if ( fullPath === nodePart.fullPath ) {
                nodeData = nodePart;
            } else {
                nodeData = _searchForNode( nodePart, fullPath, _operation.add, true );
            }
        }
        return nodeData;
    },

    //Expands all the childrens of the selected node
    _expandAllChildren = function ( selectedNode ) {
        var i = 0,
        children = selectedNode.Children,
        child,
        childCount;
        if ( _isExpandAll ) {
            selectedNode.IsExpanded = true;
        }
        if ( children ) {
            childCount = children.length;
            for ( i = 0; i < childCount; i++ ) {
                child = children[i];
                child.Visible = true;
                _expandAllChildren( child );
            }
        }
    },

    //update or set depth and index information
    _traverse = function ( node ) {
        var i = 0, childName,
        children = node.Children,
        child,
        childCount,
	    fullpath,
        prevIndexAtDepth = 0;
        prevIndexAtDepth = node.index = _count++;
        if ( _isExpandAll ) {
            node.IsExpanded = true;
        } else if ( _isCollapseAll ) {
            node.IsExpanded = false;
        }

        _linearDataArray.push( node );

        if ( children ) {
            childCount = children.length;
            for ( i = 0; i < childCount; i++ ) {
                child = children[i];
                child.ParentId = node.Id;
                child.prevIndexAtDepth = prevIndexAtDepth;
                if ( node.IsExpanded === true ) {
                    if ( _selectedFilter && _selectedFilter !== _options['TBID_NONE'] ) {
                        if ( _selectedFilter === _options['TBID_NODE_PENDINGALARMS'] && Object.keys( _alarmData ).length > 0 ) {
                            if ( ( Object.keys( _alarmData.ActiveAlarms ).length > 0 ) ) {
                                fullpath = child.fullPath;
                                if ( _alarmData.ActiveAlarms[fullpath] === 1 ) {
                                    child.Visible = true;
                                } else {
                                    child.Visible = false;
                                }
                            }
                        }
                        else if ( _selectedFilter === _options['TBID_NODE_VISUALIZATION'] && Object.keys( _screenData ).length > 0 ) {
                            if ( ( Object.keys( _screenData.ScreenFilter ).length > 0 ) ) {
                                fullpath = child.fullPath;
                                if ( _screenData.ScreenFilter[fullpath] === 0 ) {
                                    child.Visible = true;
                                } else {
                                    child.Visible = false;
                                }
                            }
                        }
                    } else {
                        child.Visible = true;
                    }
                    if ( node.depth === undefined || node.depth === null ) {
                        node.depth = 0;
                    }
                    child.depth = node.depth + 1;
                    if ( child.depth >= _deepestNode ) {
                        _deepestNode = child.depth;
                        childName = child.Name;
                    }
                } else {
                    child.Visible = false;
                }

                if ( child.Visible === true ) {
                    _traverse( child );
                    prevIndexAtDepth = child.index;
                }
            }
        }
        //node.isSelected = false;
    },

    //updates URL data
    _updateURLData = function ( node ) {
        var URLPart = _data.URLPart,
        nodePart = _data.NodePart[0], prevNode,
        nodeData;
        URLPart.data.length = 0;
        //selected node is hierarchy node
        if ( node.Id === nodePart.Id ) {
            nodeData = { name: nodePart.Name, id: nodePart.Id, height: null, width: null, IsLeaf: nodePart.IsLeaf };
            URLPart.data.push( nodeData );
            _fillBBoxInfo( nodeData );
        }
        else {//selected node is view root or view node
            nodeData = { name: node.Name, id: node.Id, height: null, width: null, IsLeaf: node.IsLeaf };
            URLPart.data.push( nodeData );
            _fillBBoxInfo( nodeData );

            prevNode = node;
            while ( prevNode.Id !== nodePart.Id ) {
                if ( prevNode.ParentId === nodePart.Id ) {
                    nodeData = { name: nodePart.Name, id: nodePart.Id, height: null, width: null, IsLeaf: nodePart.IsLeaf };
                    URLPart.data.push( nodeData );
                    _fillBBoxInfo( nodeData );
                    break;
                }
                prevNode = _searchForNode( nodePart, prevNode.ParentId, _operation.add );
                nodeData = { name: prevNode.Name, id: prevNode.Id, height: null, width: null, IsLeaf: prevNode.IsLeaf };
                URLPart.data.push( nodeData );
                _fillBBoxInfo( nodeData );
            }
        }
        _calculateViewPortURLData();
    },

    //calculate viewport URL data from entire URL data
    _calculateViewPortURLData = function () {
        var i = 0,
        URLPart = _data.URLPart,
        dataLength = URLPart.data.length,
        viewportDataLength,
        offset = ( URLPart.imageIcon.width ),
        availableWidth = ( URLPart.border.width - offset ) > 0 ? ( URLPart.border.width - offset ) : 0,
        coveredWidth = 0;
        URLPart.viewportData.length = 0;
        if ( availableWidth > coveredWidth ) {
            for ( i = 0; i < dataLength; i++ ) {
                if ( ( coveredWidth + ( URLPart.data[i].width + URLPart.textPadding.left + URLPart.textPadding.right ) + URLPart.imageIcon.width ) < availableWidth ) {
                    URLPart.viewportData.push( URLPart.data[i] );
                    coveredWidth += URLPart.data[i].width + URLPart.textPadding.left + URLPart.textPadding.right + URLPart.imageIcon.width;
                }
                else {
                    break;
                }
            }
            //calculate text x-position
            viewportDataLength = URLPart.viewportData.length;
            coveredWidth = offset;
            for ( i = viewportDataLength - 1; i >= 0; i-- ) {
                URLPart.viewportData[i].x = coveredWidth;
                coveredWidth += ( URLPart.viewportData[i].width + URLPart.textPadding.left + URLPart.textPadding.right + URLPart.imageIcon.width );
            }
        }
        _breadCrumb.updateNodeURL( URLPart );
    },

    _searchForNode = function ( node, searchStr, operation, isFullPath ) {
        var
        children,
        child,
        length,
        retVal,
        isFound = false;
        if ( node && node.Children && node.Children.length > 0 ) {
            children = node.Children;
            length = children.length;
            while ( length-- ) {
                child = children[length];
                if ( searchStr && searchStr !== '' ) {
                    if ( isFullPath ) {
                        isFound = ( child.fullPath === searchStr ) ? true : false;
                    }
                    else {
                        isFound = ( child.Id.toLowerCase() === searchStr.toLowerCase() ) ? true : false;
                    }
                    if ( isFound ) {
                        switch ( operation ) {
                            case _operation.remove:
                                children.splice( children.indexOf( child ), 1 );
                                retVal = true;
                                break;
                            case _operation.add:
                                retVal = child;
                                break;
                            default:
                                break;
                        }
                    }
                    else if ( !child.IsLeaf && !retVal ) {
                        retVal = _searchForNode( child, searchStr, operation, isFullPath );
                    }
                }
            }
        }
        return retVal;
    },

    _alarmIconGrpCallback = function () {
        var y;
        if ( _data.Width < _deepestNodeWidth ) {
            y = _toolbarHeight + CPM.Enums.Constants.urlHeight;
            _nodeHandler.updateAlarmIconGrp( _deepestNodeWidth, y );
            _createHorizontalScrollBar();
        }
    },


    _onScroll = function ( direction, scrollBar, evt ) {
        var yValue, xValue, pageScrollCount;
        switch ( scrollBar ) {
            case 'bcVScroll':
                if ( _isBCVerticalScrollbarCreated ) {
                    if ( direction && ( _prevBCScrollPerc + _vBCScrollStep <= 1 ) ) {
                        _prevBCScrollPerc = _prevBCScrollPerc + _vBCScrollStep;
                    } else if ( !direction && ( _prevBCScrollPerc > 0 && ( _prevBCScrollPerc - _vBCScrollStep >= 0 ) ) ) {
                        _prevBCScrollPerc = _prevBCScrollPerc - _vBCScrollStep;
                    }
                    if ( _prevBCScrollPerc !== 0 ) {
                        yValue = -( _prevBCScrollPerc * _vBCScrollHeight );
                    }
                    else {
                        yValue = 0;
                    }
                    _breadcrumbGroupMatrix.f = yValue;
                    _createBCVerticalScrollBar();
                }
                break;
            case 'VScroll':
                if ( _isScrollbarCreated ) {
                    if ( direction && ( _vScrollStep + _prevScrollPerc <= 1 ) ) {
                        _prevScrollPerc = _vScrollStep + _prevScrollPerc;
                        if ( evt && evt.keyCode === 34 ) {
                            pageScrollCount = _vpNodeCount + _scrollCount;
                            _prevScrollPerc = pageScrollCount / ( _count - _vpNodeCount );
                        }
                        _scrollCallBack( null, null, null, _prevScrollPerc );
                        _createVerticalScrollBar();
                    } else if ( !direction && ( _prevScrollPerc > 0 && ( ( _prevScrollPerc - _vScrollStep ) >= 0 ) ) ) {
                        _prevScrollPerc = _prevScrollPerc - _vScrollStep;
                        if ( evt && evt.keyCode === 33 ) {
                            pageScrollCount = _scrollCount - _vpNodeCount;
                            _prevScrollPerc = pageScrollCount / ( _count - _vpNodeCount );
                        }
                        _scrollCallBack( null, null, null, _prevScrollPerc );
                        _createVerticalScrollBar();
                    }
                }
                break;
            case 'HScroll':
                if ( _isHorizontalScrollbarCreated ) {
                    if ( direction && ( _horizontalInitialScrollOffset + _hScrollStep <= 1 ) ) {
                        _horizontalInitialScrollOffset = _horizontalInitialScrollOffset + _hScrollStep;
                    } else if ( !direction && ( _horizontalInitialScrollOffset > 0 && ( _horizontalInitialScrollOffset - _hScrollStep >= 0 ) ) ) {
                        _horizontalInitialScrollOffset = _horizontalInitialScrollOffset - _hScrollStep;
                    }
                    if ( _horizontalInitialScrollOffset !== 0 ) {
                        xValue = -( _horizontalInitialScrollOffset * _hScrollWidth );
                    }
                    else {
                        xValue = 0;
                    }
                    _createHorizontalScrollBar();
                    _treeGroupMatrix.e = xValue;
                }
                break;
            default:
                break;
        }
    },

    _scrollCallBack = function ( _id, changeType, abs, perc ) {
        var nodeBBoxInfo, y, vCount = _count;//, percentile;
        _prevScrollPerc = perc;
        if ( _addExtraScroll ) {
            vCount++;
        }
        _scrollCount = Math.round(( vCount - _vpNodeCount ) * perc );
        //Below _scrollCount check is required for handling Page Up and Page Down events
        if ( _scrollCount < 0 ) {
            _scrollCount = 0;
        } else if ( _scrollCount > vCount - _vpNodeCount ) {
            _scrollCount = Math.round( vCount - _vpNodeCount );
        }
        nodeBBoxInfo = _nodeHandler.onScroll( _scrollCount );
        _updateNodeBBox( nodeBBoxInfo );
        _createHorizontalScrollBar();  //required when vertical scrollbar overlaps on top of alarm icon
        if ( ( _data.Width < _deepestNodeWidth ) && ( _alarmData.ActiveAlarms && Object.keys( _alarmData.ActiveAlarms ).length > 0 ) ) {
            y = _toolbarHeight + CPM.Enums.Constants.urlHeight;
            _deepestNodeWidth = _deepestNodeWidth - CPM.Enums.Constants.alarmIconToTextGap;
            _nodeHandler.updateAlarmIconGrp( _deepestNodeWidth, y, true ); //donot update alarm icons, only update rectangle width
            _createHorizontalScrollBar();
        }

    },

    _scrollCallBackBC = function ( _id, changeType, abs, perc ) {
        var yValue;
        _prevBCScrollPerc = perc;
        if ( perc !== 0 ) {
            yValue = -abs;
        }
        else {
            yValue = 0;
        }
        _breadcrumbGroupMatrix.f = yValue;
    },

    _scrollCallBackHoriz = function ( _id, changeType, abs, perc ) {
        var xValue;
        _horizontalInitialScrollOffset = perc;
        if ( perc !== 0 ) {
            xValue = -abs;
        } else {
            xValue = 0;
        }
        _horizontalInitialScrollOffset = perc;
        _treeGroupMatrix.e = xValue;
    },

    _handleVScrollBar = function ( mousePoint, targetGroup, event, target ) {
        _scrollVerticalHandler.onScrollEvent( mousePoint, targetGroup, event, target );
        _unloadBreadCrumb();
    },

    _handleBCVScrollBar = function ( mousePoint, targetGroup, event, target ) {
        _scrollBCVerticalHandler.onScrollEvent( mousePoint, targetGroup, event, target );
    },

    _handleCBVScrollBar = function ( mousePoint, targetGroup, event, target ) {
        _filterComboBox.cbScrollVerticalHandler.onScrollEvent( mousePoint, targetGroup, event, target );
    },

    _handleHScrollBar = function ( mousePoint, targetGroup, event, target ) {
        _scrollHorizontalHandler.onScrollEvent( mousePoint, targetGroup, event, target );
    },

    _applyResize = function ( height ) {
        var actualHeight;
        if ( height > _ctrlHeight ) {
            actualHeight = height;
            _svgParent.setAttribute( 'height', ( height + 'px' ) );
        }
        else {
            actualHeight = _ctrlHeight;
            _svgParent.setAttribute( 'height', ( _ctrlHeight + 'px' ) );
        }
        _createVerticalScrollBar();
        _createHorizontalScrollBar();
        _updateBgRects();
        _setForUpdate();
        _alarmIconGrpCallback();
    },

    _createVerticalScrollBar = function () {
        var
        left = _data.Left + _data.Width - 22, settings = {}, totalHeight, viewPortHeight, vCount = _count,
        topValue = _urlPartTotalHeight + _toolbarHeight;
        totalHeight = _count * _nodeHeight;
        viewPortHeight = _ctrlHeight - ( _urlPartTotalHeight + _toolbarHeight );
        //Do not create vertical scrollbar if total height of tree is within viewport height or if viewport height is lesser than the node height i.e. height of one tree node.
        if ( viewPortHeight >= totalHeight || viewPortHeight < _nodeHeight ) {
            if ( _isScrollbarCreated ) {
                _scrollVerticalHandler.remove();
                _isScrollbarCreated = false;
                _scrollCount = 0;
            }
            return;
        }
        if ( _addExtraScroll ) {
            vCount++;
        }
        settings.width = 17;
        settings.height = _data.CtrlHeight - _urlPartTotalHeight - _toolbarHeight;
        settings.height = settings.height < 0 ? 0 : settings.height;
        settings.id = 'tree_';
        settings.startValue = 0;
        settings.endValue = vCount - Math.round( _vpNodeCount );

        settings.initialScrollOffset = 0;
        settings.initialHeightPerc = ( _vpNodeCount ) / ( vCount );
        _vScrollStep = settings.scrollStep = 1 / ( vCount - Math.ceil( _vpNodeCount ) );
        settings.horizontalSliderHeight = 17;
        if ( _isScrollbarCreated ) {
            _scrollVerticalHandler.remove();
            _prevScrollPerc = settings.initialScrollOffset = _scrollCount / ( settings.endValue );
        }
        _isScrollbarCreated = true;
        _scrollVerticalHandler.createScrollBar( settings, left, topValue, _scrollbarGrp, _scrollCallBack, false );

    },

    // Vertical scroll bar for Breadcrumb 
    _createBCVerticalScrollBar = function () {
        var settings = {},
        left = _crumbX + _crumbNodeNameWidth + 40,
        topValue = _toolbarHeight + CPM.Enums.Constants.urlHeight,
        totalHeight = _crumbChildren.length * _nodeDomHeight;
        if ( ( _ctrlHeight - topValue - _toolbarHeight) > totalHeight ) {
            if ( _isBCVerticalScrollbarCreated ) {
                _scrollBCVerticalHandler.remove();
                _isBCVerticalScrollbarCreated = false;
            }
            return;
        }
        settings.width = 15;
        settings.horizontalSliderHeight = 15;
        if ( _isHorizontalScrollbarCreated ) {
            settings.height = _ctrlHeight - topValue - _hScrollbarHeight;
            _vBCScrollHeight = settings.endValue = _nodeDomHeight * _crumbChildren.length - _ctrlHeight + topValue +_hScrollbarHeight;
        } else {
            settings.height = _ctrlHeight - topValue;
            _vBCScrollHeight = settings.endValue = _nodeDomHeight * _crumbChildren.length - _ctrlHeight + topValue;
        }
        _vBCScrollStep = settings.scrollStep = 1 / _crumbChildren.length;
        settings.initialHeightPerc = ( _ctrlHeight - _toolbarHeight - _nodeDomHeight ) / ( _crumbChildren.length * _nodeDomHeight );
        settings.initialScrollOffset = 0;
        settings.id = 'bc_';
        if ( _isBCVerticalScrollbarCreated ) {
            _scrollBCVerticalHandler.remove();
            settings.initialScrollOffset = ( _prevBCScrollPerc * _vBCScrollHeight ) / ( settings.endValue );
        }
        _scrollBCVerticalHandler.createScrollBar( settings, left, topValue, _scrollbarGrp, _scrollCallBackBC, false );
        _isBCVerticalScrollbarCreated = true;
    },

    _createHorizontalScrollBar = function () {
        var
        left = 0, settings = {}, viewPortHeight,
        topValue = _data.CtrlHeight + _nodeHeight - _data.ToolbarPart.border.topVal - 50;
        _hScrollbarHeight = 17;
        settings.width = _data.CtrlWidth;
        viewPortHeight = _ctrlHeight - _urlPartTotalHeight + _data.Top - _toolbarHeight;

        if ( _isScrollbarCreated ) {
            settings.width = _data.CtrlWidth - 17;	//vertical scroll bar width = 17
        }
        if ( _alarmData.ActiveAlarms && Object.keys( _alarmData.ActiveAlarms ).length > 0 ) {
            _deepestNodeWidth = _deepestNodeWidth + CPM.Enums.Constants.alarmIconToTextGap;
        }

        //Do not create horizontal scrollbar if deepest node width of tree is within viewport width or if viewport height is lesser than the node height i.e. height of one tree node.
        if ( _deepestNodeWidth < settings.width || viewPortHeight < _nodeHeight ) {
            if ( _isHorizontalScrollbarCreated ) {
                _scrollHorizontalHandler.remove();
                _isHorizontalScrollbarCreated = false;
                _treeGroupMatrix.e = 0;
            }
            return;
        } else {
            settings.horizontalSliderHeight = _hScrollbarHeight;
            settings.height = _hScrollbarHeight;
            _hScrollWidth = settings.endValue = _deepestNodeWidth - settings.width;
            _hScrollStep = settings.scrollStep = ( 1 / settings.endValue ) * 10;
            settings.initialHeightPerc = ( settings.width ) / ( _deepestNodeWidth );
            settings.initialScrollOffset = 0;
            if ( _isHorizontalScrollbarCreated ) {
                _scrollHorizontalHandler.remove();
                if ( _horizontalInitialScrollOffset ) {
                    settings.initialScrollOffset = _horizontalInitialScrollOffset;
                }
                _isHorizontalScrollbarCreated = false;
                _treeGroupMatrix.e = 0;
            }
            _scrollHorizontalHandler.createScrollBar( settings, left, topValue, _svgParent, _scrollCallBackHoriz, true );
            _isHorizontalScrollbarCreated = true;
        }
    },

    _getNodeDomHeight = function () {
        return _nodeHeight;
    },

    //update Parent Dims
    _updateParentDims = function () {
        var treeControl, treeViewPortHeight;
        if ( _svgParent ) {
            treeControl = _svgParent.firstElementChild; //TODO:Remove hard coded id
            if ( treeControl && treeControl.getBBox ) {
                treeViewPortHeight = _urlPartTotalHeight + ( ( _count ) * _nodeHeight );
                _applyResize( treeViewPortHeight );
            }
        }
    },

    _toRGBA = function ( num ) {
        /*jslint bitwise: true */
        num >>>= 0;
        var b = num & 0xFF,
        g = ( num & 0xFF00 ) >>> 8,
        r = ( num & 0xFF0000 ) >>> 16,
        a = ( ( num & 0xFF000000 ) >>> 24 ) / 255;
        /*jslint bitwise: false */

        return 'rgba(' + [r, g, b, a].join( ',' ) + ')';
    },

    _isNodeInViewport = function ( index ) {
        if ( index >= _scrollCount && ( index < _vpNodeCount + _scrollCount ) ) {
            return true;
        } else {
            return false;
        }
    },

    _traverseRawdata = function ( nodeObj ) {
        var i = 0, childName, node = {}, formattedNode,
        children,
        child,
        childCount,
        prevIndexAtDepth = 0;
        prevIndexAtDepth = node.index = _count++;
        node.Name = nodeObj[0];

        node.Id = nodeObj[1];
        if ( nodeObj[5] ) {
            node.InstanceId = nodeObj[5];
        }
        node.ChildCount = nodeObj[3];
        node.fullPath = nodeObj[2];
        if ( nodeObj[5] === '0.0.0.0.0.0' ) {
            node.IsLinked = false;
        } else {
            node.IsLinked = true;
        }
        node.IsExpanded = false;
        node.IsLeaf = true;
        node.ParentId = nodeObj.ParentId;
        if ( nodeObj.depth === undefined || nodeObj.depth === null ) {
            node.depth = 0;
        }
        else {
            node.depth = nodeObj.depth;
        }
        if ( nodeObj.length > 6 && nodeObj[6].length > 0 ) {//Children array is sent at the 6th index from server
            children = nodeObj[6].splice( 0 );
            node.Children = [];
            node.IsExpanded = true;
            node.IsLeaf = false;
        }
        if ( node.ChildCount > 0 ) {
            node.IsLeaf = false;
        }
        node.height = TEXT_BBOX.height;
        if ( children ) {
            childCount = children.length;
            for ( i = 0; i < childCount; i++ ) {
                child = children[i];
                child.ParentId = node.Id;
                child.prevIndexAtDepth = prevIndexAtDepth;
                if ( node.IsExpanded === true ) {
                    child.depth = node.depth + 1;
                    if ( child.depth >= _deepestIdx ) {
                        _deepestNode = child[1];
                        _deepestIdx = child.depth;
                        childName = child[0];
                    }
                }
                formattedNode = _traverseRawdata( child );
                node.Children.push( formattedNode );
                prevIndexAtDepth = child.index;
            }
        }
        node.isSelected = false;
        if ( _prevNodeSelected && _prevNodeSelected.Id === node.Id ) {
            node.isSelected = true;
        }
        return node;
    },

    _unloadBreadCrumb = function () {
        _crumbChildren = [];
        _showCrumb = false;
        _treeGroup.setAttribute( 'fill-opacity', '1' );
        _clickedURLNodeId = null;
        _isBreadCrumbCreated = false;
        _prevHoveredNodeId = null;
        if ( _isBCVerticalScrollbarCreated ) {
            _isBCVerticalScrollbarCreated = false;
            _scrollBCVerticalHandler.remove();
            _breadcrumbGroupMatrix.f = 0;
            _prevBCScrollPerc = 0;
        }
        _breadCrumb.unloadBreadCrumb();
        _breadCrumb.updateNodeImage();   // reset the arrow of URL part if empty area of viewport is clicked
    },

    _createBgRects = function () {
        var count, nodeHeight, data = {};
        nodeHeight = _getNodeDomHeight();
        _treeGroup = document.getElementById( 'treeGroup' );
        _treeGroupMatrix = _treeGroup.transform.baseVal.getItem( 0 ).matrix;
        count = ( _data.CtrlHeight - _urlPartTotalHeight - _toolbarHeight ) / nodeHeight;
        //Checking if the total count of bg rects is a whole number. If its whole number then all the bg rects are drawn completely. Hence scrolling should not be adjusted.
        //If the count contains decimal values that means the last bg rect is partially drawn. Hence we add an extra scroll step to the scrollbar so that the last node data is fully displayed on last scroll.
        if ( count !== Math.floor( count ) ) {
            _addExtraScroll = true;
        } else {
            _addExtraScroll = false;
        }
        count = _vpNodeCount = Math.ceil( count );
        data.Top = _data.Top + _data.ToolbarPart.border.height;
        data.Left = _data.Left;
        data.active = _data.active;
        data.SelectionForeColor = _data.SelectionForeColor;
        data.Width = _data.Width;
        data.white = _data.white;
        data.grey3 = _data.grey3;
        if ( _deepestNodeWidth && data.Width < _deepestNodeWidth && _isHorizontalScrollbarCreated ) {
            data.Width = _deepestNodeWidth;
        }
        _nodeHandler.createBgRects( count, _treeGroup, nodeHeight, data );
    },

    _updateBgRects = function () {
        while ( _treeGroup.firstChild ) {
            _treeGroup.removeChild( _treeGroup.lastChild );
        }
        _createBgRects();
    },

    _createBCRects = function () {
        var data = {};
        data.Left = _data.Left;
        data.Top = _data.ToolbarPart.border.height;
        data.Width = _data.Width;
        data.BackColor = _data.BackColor;
        data.imageWidth = _data.URLPart.imageIcon.width;
        data.nodeHeight = _getNodeDomHeight();
        data.borderHeight = _data.URLPart.border.height;
        data.borderWidth = _data.URLPart.border.width;
        data.strokeWidth = _data.URLPart.border.strokeWidth;
        data.Font = _data.Font;
        _breadCrumb.createBCRects( _treeControlGroup, data );
        _breadCrumb.createURLPart( _data.URLPart );
    },
    //Creates toolbar expand, collapse buttons and background rect behind those buttons
    _createToolbar = function () {
        var data = {};
        data.Left = _data.Left;
        data.white = _data.white;
        data.ToolbarPart = _data.ToolbarPart;
        data.Enabled = _data.Enabled;
        _toolbar.createToolbar( _treeControlGroup, data );
    },
    //Creates background rect adjacent to expand, collapse buttons
    _createToolbarBackRect = function () {
		var data = {};
        data.Left = _data.Left;
        data.Width = _data.CtrlWidth;
        data.white = _data.white;
        data.ToolbarPart = _data.ToolbarPart;
        _toolbar.createToolbarBackRect( _treeControlGroup, data );
     },
    _callbackOnSelect = function ( data ) {
        var values = _getValues( _options );
        if ( _selectedFilter === values[data] ) {
            return;//Do nothing if the filter is already applied.
        }
        _selectedFilter = values[data];
        if ( _selectedFilter === _options['TBID_NODE_PENDINGALARMS'] ) {
            WebCC.Properties.Filter = CPM.Enums.Filter.NodeWithPendingAlarms;
        } else if ( _selectedFilter === _options['TBID_NODE_VISUALIZATION'] ) {
            WebCC.Properties.Filter = CPM.Enums.Filter.NodeWithVisualization;
        } else {
            WebCC.Properties.Filter = CPM.Enums.Filter.None;
        }

        _filterComboBox.setSelectedOption( _selectedFilter );
        self.filter();
    },
    _createFilterDropDown = function () {
        var styles, comboGroup, attributes = {};
        _comboBoxHandler = new CPM.ComboBoxHandler( _svgParent );
        styles = {
            comboBoxStyles: { fill: _comboBoxHandler.getGuideStyles( CPM.Enums.ComboGradients.IOFieldNormal ) },
            normalbuttonStyles: { fill: _comboBoxHandler.getGuideStyles( CPM.Enums.ComboGradients.ButtonNormal ) },
            pressedbuttonStyles: { fill: _comboBoxHandler.getGuideStyles( CPM.Enums.ComboGradients.ButtonPressed ) }
        };
        _filterComboBox = new CPM.ComboBox( _id, _callbackOnSelect, undefined, styles );
        _options['TBID_NONE'] = WebCC.Extensions.X_Textbib.getText( 'TBID_NONE' );
        if ( _alarmComapnion ) {
            _options['TBID_NODE_PENDINGALARMS'] = WebCC.Extensions.X_Textbib.getText( 'TBID_NODE_PENDINGALARMS' );
        }
        if ( _screenWindowCompanion ) {
            _options['TBID_NODE_VISUALIZATION'] = WebCC.Extensions.X_Textbib.getText( 'TBID_NODE_VISUALIZATION' );
        }
        _filterComboBox.setOptions( _getValues( _options ) );
        comboGroup = CPM.svgUtil.createSVG( 'g',
            {
                id: 'comboGroup',
                appendTo: _treeControlGroup
            } );
        attributes = _getFilterComboBoxAttributes();
        _filterComboBox.draw( comboGroup, attributes, 400 );
        switch ( WebCC.Properties.Filter ) {
            case CPM.Enums.Filter.NodeWithPendingAlarms:
                _selectedFilter = _options['TBID_NODE_PENDINGALARMS'];
                break;
            case CPM.Enums.Filter.NodeWithVisualization:
                _selectedFilter = _options['TBID_NODE_VISUALIZATION'];
                break;
            default:
                _selectedFilter = _options['TBID_NONE'];
                break;
        }
        _filterComboBox.setSelectedOption( _selectedFilter );

        //dropDown.show();
    },

    _getFilterComboBoxAttributes = function () {
        var comboLeftPadding = 149, comboRightPadding = 20,
            attributes = {
                height: _data.ToolbarPart.border.buttonHeight,
                left: _data.Left + comboLeftPadding,
                optionsLeft: _data.Left + comboLeftPadding,
                optionsWidth: _data.Width - ( comboLeftPadding + comboRightPadding ),
                top: _data.ToolbarPart.border.buttonTop,
                width: _data.Width - ( comboLeftPadding + comboRightPadding ),
                ctrlHeight: _data.CtrlHeight
            };

        if ( !_comboMaxWidth ) {
            _comboMaxWidth = _filterComboBox.getMaxWidth();
        }

        if ( attributes.width > _comboMaxWidth ) { //Restrict the maximum combobox width to width of the longest option and keep it right aligned if the width of the control is more.
            attributes.optionsLeft = attributes.left = _data.Left + _data.Width - _comboMaxWidth - comboRightPadding;
            attributes.width = _comboMaxWidth;
            attributes.optionsWidth = _comboMaxWidth;
        } else if ( ( attributes.width > attributes.height ) && ( attributes.width < ( _comboMaxWidth - attributes.height ) ) ) { //Shift the combobox options to the left if there is enough space to display complete text of the options. 
            attributes.optionsLeft = _data.Left + _data.Width - _comboMaxWidth + attributes.height - comboRightPadding;
            attributes.optionsWidth = _comboMaxWidth - attributes.height;
            _prevComboLeft = attributes.left;
        } else if ( attributes.width <= attributes.height ) { //Restrict the minimum combobox width to the combobox icon width
            attributes.width = attributes.height;
            if ( _prevComboLeft ) {
                attributes.left = _prevComboLeft;
            }
            if ( attributes.optionsWidth < _data.Width ) {
                attributes.optionsWidth = _data.Width - 10;
            }
            if ( _comboMaxWidth > _data.Width ) {
                attributes.optionsLeft = _data.Left;
            }
        }

        return attributes;
    },

    _setBeforeTraverse = function () {
        _count = 0;
        _linearDataArray = [];
        _traverse( _data.NodePart[0] );
    },

    _updateNodeBBox = function ( nodeBBoxInfo ) {
        if ( nodeBBoxInfo ) {
            _deepestNodeWidth = nodeBBoxInfo.nodeWidth;
            TEXT_BBOX = nodeBBoxInfo.textBBox;
            _createHorizontalScrollBar();
        }
    },

    _setForUpdate = function ( alarmData ) {
        var nodeBBoxInfo,
        isResetScrollIndexReq = false;
        if ( !_scrollCount ) {
            isResetScrollIndexReq = true;
        }
        nodeBBoxInfo = _nodeHandler.updateBgRects( _linearDataArray, isResetScrollIndexReq, _data.Font, alarmData );
        //_updateNodeBBox( nodeBBoxInfo );
        //Calling _updateNodeBBox is resetting TEXT_BBOX which is not required here.

        if ( nodeBBoxInfo ) {
            _deepestNodeWidth = nodeBBoxInfo.nodeWidth;
            _createHorizontalScrollBar();
        }       
        if ( _tbUpdateRequired && _prevNodeSelected ) {
            _tbUpdateRequired = false;
            _updateToolbarButtons( _prevNodeSelected );
        }
    },

    _resetScrollCount = function ( nodeData ) {
        var nodeBBoxInfo;
        if ( _count > _vpNodeCount ) {
            if ( nodeData.index < ( _count - _vpNodeCount ) ) {
                _scrollCount = nodeData.index;
            }
            else {
                _scrollCount = Math.round( _count - _vpNodeCount );
            }
        }
        nodeBBoxInfo = _nodeHandler.onScroll( _scrollCount );
        _updateNodeBBox( nodeBBoxInfo );
        _createVerticalScrollBar();
        _unloadBreadCrumb();
    },

    _resetTree = function () {
        var selectedNode;
        if ( _selectedNodeId ) {
            selectedNode = _getNodeData( _selectedNodeId );
            selectedNode.isSelected = false;
            _nodeHandler.setSelectedNode( selectedNode );
            _selectedNodeId = undefined;
        }
        _prevNodeSelected = null;
        _prevSelectedCrumbNode = null;
        _prevSelectedBCNodeId = null;
        _deepestNodeWidth = 0;
        _treeGroupMatrix.e = 0;
        _horizontalInitialScrollOffset = 0;
        _scrollCount = 0;
        _unloadBreadCrumb();
        _updateURLData( _data.NodePart[0] );
    },

    _sendSummaryInfo = function ( nodeData ) {
        var nodePath, paramValues, filterString;
        if ( _alarmComapnion ) {
            if ( !nodeData ) {
                nodePath = _data.NodePart[0].fullPath;
                paramValues = [9, 'Area = \'' + nodePath + '\'' + ' OR Area LIKE \'' + nodePath + '/*\''];
                WebCC.Extensions.HMI.DomainLogic.sendDLEvent( [0, 1], paramValues );
            }
            else {
                nodePath = nodeData.fullPath;
                // nodePath = nodePath.split( '\\' ).join( '\\\\' );
                filterString = 'Area = \'' + nodePath + '\'' + ' OR Area LIKE \'' + nodePath + '/*\'';
                if ( _alarmComapnion.CompanionConfig && _alarmComapnion.CompanionConfig.AlarmClassFilter ) {
                    filterString = filterString + ' AND ' + _alarmComapnion.CompanionConfig.AlarmClassFilter;
                }
                paramValues = [10,
                    CPM.Enums.CompanionTypes.Alarm,
                    _alarmComapnion.ControlRef,
                    filterString
                ];

                WebCC.Extensions.HMI.DomainLogic.sendDLEvent( [0, 1, 2, 3], paramValues );
            }
        }
    },

    _setScreenCompanions = function () {
        var idx, length = WebCC.Properties.Companions.length, control;
        for ( idx = 0; idx < length; idx++ ) {
            control = WebCC.Properties.Companions[idx];
            if (control && control.ControlRef) {
                if ( control.ControlType === 'AlarmControl' ) {
                    if ( !_alarmComapnion && control.CompanionConfig && control.CompanionConfig.ShowAlarmSummary ) {
                        _alarmComapnion = control;
                        if ( !_createFilter ) {
                            _createFilter = true;
                        }
                    }
                }
                else if ( control.ControlType === 'ScreenWindow' ) {
                    if ( !_screenWindowCompanion ) {
                        _screenWindowCompanion = control;
                        if ( !_createFilter ) {
                            _createFilter = true;
                        }
                    }

                }
                else if ( control.ControlType === 'Calendar Control' ) {
                    if ( !_shcCompanion ) {
                        _shcCompanion = control;
                    }

                }
            }
        }
    },
    _showToolTip = function ( target, position ) {
        var trendIndex, temp, toolTipText, targetText;
        temp = target.id.split( '_' );
        trendIndex = parseInt( temp[temp.length - 1] );

        if ( isNaN( trendIndex ) ) {//Mouse hover on the selected trend in combobox
            if ( target.id === _id + '_ComboBox_OptionNumber_SelectedNode' ) {
                toolTipText = _selectedFilter;
                targetText = target.parentNode.textContent;
            }
        } else {//Mouse hover on the combobox options
            toolTipText = _getValues( _options )[trendIndex];
            targetText = _svgParent.getElementById( _id + '_ComboBox_SvgOptionNode_' + trendIndex ).textContent;
        }
        if ( toolTipText !== targetText ) {
            CPM.Common.Tooltip.show( position.x, position.y, toolTipText );
        }
    },
    _getEventHandlers = function () {
        return {
            handleVScrollBar: _handleVScrollBar,
            handleHScrollBar: _handleHScrollBar,
            unloadBreadCrumb: _unloadBreadCrumb,
            toggleVisibility: self.toggleVisibility,
            getNodeData: _nodeHandler.getNodeData,
            handleBCVScrollBar: _handleBCVScrollBar,
            handleCBVScrollBar: _handleCBVScrollBar,
            selectNode: _setSelected,
            sendSummaryInfo: _sendSummaryInfo,
            getBCNode: _breadCrumb.getBCNode,
            displayImmediateChildren: _displayImmediateChildren,
            onURLClick: _onURLClick,
            setBgColor: _breadCrumb.setBgColor,
            getCrumbNode: _breadCrumb.getCrumbNode,
            setSelectedFromBC: _setSelectedFromBC,
            expandAll: self.expandAll,
            collapseAll: self.collapseAll,
            onScroll: _onScroll,
            updateNodeImage: _breadCrumb.updateNodeImage,
            updateToolbarColor: _toolbar.updateToolbarColor,
            filterComboBox: _filterComboBox,
            showToolTip: _showToolTip
        };
    },

    _addTifLibExpandoProps = function () {
        _svgParent.TifProperties = {
            tif: {},
            item: {
                nodes: _data.NodePart[0],
                findNode: function ( nodeId ) {
                    return _getNodeData( nodeId );
                },
                setFocus: function ( nodeId ) {
                    var nodeData = _getNodeData( nodeId );
                    _resetScrollCount( nodeData );
                }
            }
        };
    },

    _sendDLEventForCompanions = function ( instanceId ) {
        var paramValues;
        if ( _screenWindowCompanion ) {
            paramValues = [
                CPM.Enums.BrowsingMode.ScreenWindow,
                CPM.Enums.CompanionTypes.ScreenWindow,
                _screenWindowCompanion.ControlRef, instanceId];
            WebCC.Extensions.HMI.DomainLogic.sendDLEvent( [0, 1, 2, 3], paramValues );
        }
        if ( _shcCompanion ) {
            paramValues = [CPM.Enums.BrowsingMode.AlarmOrSHC,
                   CPM.Enums.CompanionTypes['Calendar Control'],
                   _shcCompanion.ControlRef,
                   _selectedNodePath
            ];
            WebCC.Extensions.HMI.DomainLogic.sendDLEvent( [0, 1, 2, 3], paramValues );
        }
    },

    _displayImmediateChildren = function ( event, targetNode, isBreadCrumbCreated ) {
        var nodeData, paramIds, node, paramValues;
        node = _breadCrumb.getBCNode( targetNode );
        _clickedURLNodeId = node.id;
        if ( isBreadCrumbCreated ) {
            _isBreadCrumbCreated = true;
        }
        if ( _isBreadCrumbCreated ) {
            if ( _prevHoveredNodeId !== node.id || _prevHoveredNodeId === null ) {
                _unloadBreadCrumb();
                _showCrumb = true;
                _isBreadCrumbCreated = true;
                nodeData = _getNodeData( node.id );
                paramIds = [CPM.Enums.ObjectCountAttributes.Requested, CPM.Enums.ObjectCountAttributes.TreeOrList, CPM.Enums.ObjectCountAttributes.SystemId, CPM.Enums.ObjectCountAttributes.ObjectId, CPM.Enums.ObjectCountAttributes.SelectedNode, CPM.Enums.ObjectCountAttributes.NameFilter,
                                CPM.Enums.ObjectCountAttributes.PropertyFilter, CPM.Enums.ObjectCountAttributes.LanguageId, CPM.Enums.ObjectCountAttributes.BrowsingMode, CPM.Enums.ObjectCountAttributes.SortingMode, CPM.Enums.ObjectCountAttributes.SortByAttribute];
                paramValues = [8, CPM.Enums.View.Tree, 0, , node.id, , , CPM.Enums.Language.English, CPM.Enums.BrowsingMode.ViewNode, , ]; //4 == VIEWROOT
                WebCC.Extensions.HMI.DomainLogic.sendDLEvent( paramIds, paramValues );
                _prevHoveredNodeId = node.id;
            }
            // setting horizontal distance for breadcrumb
            _crumbX = node.x + _data.URLPart.textPadding.left; // according to Cadera design
            _breadCrumb.updateNodeImage( targetNode );
        }
    },

    //fire from templete to get text Dims
    _getTextBBox = function ( text ) {
        var bbox;
        bbox = CPM.svgUtil.getTextBBox( _data.Font, '' + text );
        TEXT_BBOX = bbox;
        return bbox;
    },

    //fire from templete on URL click
    _onURLClick = function ( node ) {
        var nodeData,
        firstViewPortNodeData,
        firstViewPortNode;
        if ( node ) {
            nodeData = _getNodeData( node.id );
            _setSelected( nodeData, false, true );
        }
        else {
            firstViewPortNode = _data.URLPart.viewportData[_data.URLPart.viewportData.length - 1];
            firstViewPortNodeData = _getNodeData( firstViewPortNode.id );
            nodeData = _getNodeData( firstViewPortNodeData.ParentId );
        }

        //update URL Viewport
        _updateURLData( nodeData );
        _resetScrollCount( nodeData );

    },

    _setSelectedFromBC = function ( crumbNode ) {
        var i, nodeData, child, childCount;
        crumbNode.isSelected = true;
        if ( _prevSelectedCrumbNode ) {
            if ( _prevSelectedCrumbNode.Id === crumbNode.Id ) {
                return;
            }
            else {
                _prevSelectedCrumbNode.isSelected = false;
            }
        }
        _prevSelectedCrumbNode = crumbNode;
        _prevSelectedBCNodeId = crumbNode.Id;

        nodeData = _getNodeData( crumbNode.Id );

        if ( nodeData ) {
            nodeData.isSelected = true;
            if ( _prevNodeSelected ) {
                if ( _prevNodeSelected.Id !== crumbNode.Id ) {
                    _prevNodeSelected.isSelected = false;
                    //If full data is available and the selected node is not expanded, then expand the selected node and update the tree.
                    if ( !_prevNodeSelected.IsExpanded ) {
                        if ( _prevNodeSelected.Children ) {
                            _prevNodeSelected.IsExpanded = true;
                            childCount = _prevNodeSelected.Children.length;
                            for ( i = 0; i < childCount; i++ ) {
                                child = _prevNodeSelected.Children[i];
                                child.Visible = true;
                            }
                            _setBeforeTraverse();
                            _setForUpdate();
                        }
                    }
                } else {
                    return;
                }
            }
            _prevNodeSelected = nodeData;
            _updateToolbarButtons( _prevNodeSelected );
            // If node selected from breadcrumb is available in viewport, then update URL
            for ( i = 0; i < _linearDataArray.length; i++ ) {
                if ( _linearDataArray[i].Id === _prevNodeSelected.Id ) {
                    _updateURLData( _prevNodeSelected );
                    break;
                }
            }

            //update WebCC Properties 
            WebCC.Properties.SelectedNode = _prevNodeSelected.fullPath;
            WebCC.Events.fire( 'onSelectionChanged', nodeData.fullPath );
            _selectedNodePath = nodeData.fullPath;
            _selectedNodeId = nodeData.Id; //setting selectedNode Id
            _resetScrollCount( nodeData );
            _sendDLEventForCompanions( nodeData.InstanceId );
        } else {//If full data is not available then request the data from server for the selected node.
            WebCC.Events.fire( 'onExpand', _prevNodeSelected.fullPath );
            _prevNodeSelected.IsExpanded = true;
            _isBCUpdateRequired = true;
            _callback( { name: _prevNodeSelected.fullPath, id: _prevNodeSelected.Id, isRequestData: true, isHierarchyNode: false } );
        }

    },

    //fire from templete on node click
    _setSelected = function ( node, isCallReq, unloadBreadCrumb ) {
        node.isSelected = true;
        if ( _prevNodeSelected ) {
            if ( _prevNodeSelected.Id !== node.Id ) {
                _prevNodeSelected.isSelected = false;
            }
            else {
                if ( !unloadBreadCrumb ) {
                    _unloadBreadCrumb();
                    _breadCrumb.updateNodeImage();
                }
                return;
            }
            _nodeHandler.setSelectedNode( _prevNodeSelected );
        }
        _prevNodeSelected = node;
        _prevSelectedCrumbNode = node;
        //update URL Viewport
        _updateURLData( node );
        //update WebCC Properties
        if ( !isCallReq ) {
            _callback( { name: node.fullPath, id: node.Id, isRequestData: false } );
        }
        WebCC.Properties.SelectedNode = node.fullPath;
        _selectedNodePath = node.fullPath;
        _selectedNodeId = node.Id; //setting selectedNode Id
        _prevSelectedBCNodeId = node.Id;
        if ( !unloadBreadCrumb ) {
            _unloadBreadCrumb();
        }
        WebCC.Events.fire( 'onSelectionChanged', node.fullPath );
        _sendDLEventForCompanions( node.InstanceId );
        _nodeHandler.setSelectedNode( node );
        _updateToolbarButtons( node );
    },

    //Method to update the toolbar button state for the current selected node
    _updateToolbarButtons = function ( selectedNode ) {
        if ( selectedNode.IsFullyExpanded ) { //If the selected node is fully expanded, disable expandAll button and enable collapseAll button.
            selectedNode.IsFullyExpanded = false;
            _toolbar.setExpandBtnOpacity( 0.5 );
            _toolbar.setCollapseBtnOpacity( 1 );
        } else {
            if ( selectedNode.IsLeaf ) { //If the selected node is a leaf node, disable both the toolbar buttons.
                _toolbar.setExpandBtnOpacity( 0.5 );
                _toolbar.setCollapseBtnOpacity( 0.5 );
            } else if ( !selectedNode.IsExpanded ) { //If the selected node is collapsed, disable collapseAll button and enable expandAll button.
                _toolbar.setExpandBtnOpacity( 1 );
                _toolbar.setCollapseBtnOpacity( 0.5 );
            } else if ( selectedNode.IsExpanded ) {
                _toolbar.setCollapseBtnOpacity( 1 ); //If the selected node is expanded( not full expand), enable the collapseAll button.
                _updateExpandBtnStatus( selectedNode ); //Also, check if any of the child node or their child nodes are collapsed. If any child node is collpased, enable the expandAll button else disable it.
                if ( _enableExpandBtn ) {
                    _enableExpandBtn = false;
                    _toolbar.setExpandBtnOpacity( 1 );
                } else {
                    _toolbar.setExpandBtnOpacity( 0.5 );
                }
            }
        }
    },

    //Method to find if any of the child node under the selected node is collapsed or not.
    _updateExpandBtnStatus = function ( selectedNode ) {
        var childCount, i, child;
        if ( selectedNode.Children && !_enableExpandBtn ) {
            childCount = selectedNode.Children.length;
            for ( i = 0; i < childCount; i++ ) {
                child = selectedNode.Children[i];
                if ( !child.IsLeaf ) {
                    if ( child.IsExpanded ) {
                        _updateExpandBtnStatus( child );
                    } else {
                        _enableExpandBtn = true;
                        return;
                    }
                }
            }
        }
    },
     _getValues = function ( obj ) {
         var arr = [];
         //work around for IE as _getValues will not work in IE.
         arr = Object.keys( obj ).map( function ( key ) {
             return obj[key];
         }
         );
         return arr;
     };

    /*
    * Function to create the CPM tree control
    * @function
    * @memberOf CPM.App
    * @params{options} control data
    */
    this.createTreeControl = function ( options ) {
        var eventHandlers, desktopLayout = {};
        _svgParent = options.svgParent;
        _data.URLPart.border.width = options.width - _left - _data.URLPart.border.paddingRight;
        _data.Width = options.width;
        _data.Height = options.height;
        _data.BackColor = 'rgba(230, 230, 235, 1)';//TODO:Once back color is available from the container remove this hard coded value.
        _data.SelectionBackColor = options.SelectionBackColor ? _toRGBA( options.SelectionBackColor ) : '#7dcdf5';
        _data.SelectionForeColor = options.SelectionForeColor ? _toRGBA( options.SelectionForeColor ) : 'rgb(0,0,0)';
        _selectedNodePath = options.SelectedNodePath;
        //new styles added
        _data.DefaultBackground = '#f8f8f9';
        _data.white = '#fff';
        _data.grey3 = '#e6e6eb';
        _data.black = '#000';
        _data.active = options.SelectionBackColor ? _toRGBA( options.SelectionBackColor ) : '#7dcdf5';
        _data.BaseDir = options.BaseDir || '';
        _cntrlHeightNew = _ctrlHeight = options.height;
        _cntrlWidthNew = options.width;
        _data.CtrlHeight = _ctrlHeight;
        _data.CtrlWidth = options.width;
        _data.rtoId = options.rtoId;
        _data.Enabled = options.Enabled;
        _divParent = options.divParent;
        if ( CPM.svgUtil ) {
            CPM.svgUtil.createBBoxItems( options.domParent );
            CPM.svgUtil.setDefaultbBox( _data.Font );
        }
        _urlPartTotalHeight = _getNodeDomHeight();
        _toolbarHeight = _data.ToolbarPart.border.height;
        _nodeHandler = new CPM.svgNodeHandler( { urlPartTotalHeight: _urlPartTotalHeight, _toolbarHeight: _toolbarHeight } );
        _createBgRects();
        _breadCrumb = new CPM.breadcrumb();
        _toolbar = new CPM.toolbar();
        _treeControlGroup = CPM.svgUtil.createSVG( 'svg', {
            id: 'treeControl',
            appendTo: _svgParent
        } );
        _createBCRects();
        //Creates toolbar expand, collapse buttons and background rect behind those buttons
        _createToolbar();
        //Creates background rect adjacent to expand, collapse buttons
        _createToolbarBackRect();
        _scrollbarGrp = CPM.svgUtil.createSVG( 'g', {
            id: 'scrollbarGrp',
            appendTo: _treeControlGroup
        } );
        _setScreenCompanions();
        if ( _createFilter ) {
            _createFilterDropDown();
        }
        eventHandlers = _getEventHandlers();
        _eventManager = new CPM.EventManager( _svgParent, eventHandlers );
        _eventManager.addEventListeners( _data.BaseDir + '/libs/' );
        desktopLayout.domNode = _divParent;
        CPM.Common.Tooltip.createItems( desktopLayout );
    };

    /*
    * Function to handle node expand/collapse events
    * @function
    * @memberOf CPM.App
    * @params{node} node to be expanded or collapsed
    * @params{isCollapseAllEvent} indicates whether the function was called for collapseAll event
    */
    this.toggleVisibility = function ( node, isCollapseAllEvent ) {
        var isHierarchyNode = false, childCount, i, child;
        _isExpandAll = false;
        _isCollapseAll = false;
        if ( node.IsLeaf ) {
            _setSelected( node, true );//_selectedNodeId = node.Id;
            _callback( { name: node.fullPath, id: node.Id, isRequestData: false } );
            return;
        }
        else {
            if ( node.IsExpanded ) {
                if ( !isCollapseAllEvent ) {
                    WebCC.Events.fire( 'onCollapse', node.fullPath );
                }
                if ( node.Children ) {
                    _count = 0;
                    childCount = node.Children.length;
                    for ( i = 0; i < childCount; i++ ) {
                        child = node.Children[i];
                        if ( isCollapseAllEvent ) {
                            child.IsExpanded = false;
                        }
                        child.Visible = false;
                    }
                    _deepestNodeWidth = 0;
                    _deepestNode = 0;
                }
                node.IsExpanded = !node.IsExpanded;
                _tbUpdateRequired = true;
                _setBeforeTraverse();
                _setForUpdate();
                _scrollCount = _nodeHandler.getScrollIndex();//Fix for the issue when the scrollbar handler is not adjusted properly on last node's expand/collapse operation.
                if ( !isCollapseAllEvent ) {
                    _setSelected( node, true );//_selectedNodeId = node.Id;
                }
            }
            else {
                /*** FIXME: If hierarchies > 2 are present, send additional flag in node with sibling information and set isHierarchyNode as true ***/
                //if ( _data.NodePart[0] && node.Id === _data.NodePart[0].Id ) {
                //    isHierarchyNode = true;
                //}
                WebCC.Events.fire( 'onExpand', node.fullPath );
                node.IsExpanded = !node.IsExpanded;
                _setSelected( node, true ); //_selectedNodeId = node.Id;
                _tbUpdateRequired = true;
                if ( node.Children ) {
                    childCount = node.Children.length;
                    for ( i = 0; i < childCount; i++ ) {
                        child = node.Children[i];
                        child.Visible = true;
                    }
                    _setBeforeTraverse();
                    _setForUpdate();
                } else {
                    _callback( { name: node.fullPath, id: node.Id, isRequestData: true, isHierarchyNode: isHierarchyNode } );
                }
            }
            _updateParentDims();
        }
    };

    /*
    * Function to handle window resize event of cpm tree control
    * @function
    * @memberOf CPM.App
    * @params{height} height of the control
    * @params{width} width of the control
    */
    this.updateView = function ( height, width ) {
        var treeViewPortHeight = 0, attributes = {};
        _data.URLPart.border.width = width - _data.Left - _data.URLPart.border.paddingRight;
        _ctrlHeight = height;
        _cntrlWidthNew = width;
        _svgParent.setAttribute( 'width', ( _cntrlWidthNew + 'px' ) );
        _data.Width = _cntrlWidthNew;
       
        treeViewPortHeight = _urlPartTotalHeight + ( ( _count ) * _getNodeDomHeight() );
        if ( height > _cntrlHeightNew || treeViewPortHeight < _cntrlHeightNew ) {
            _cntrlHeightNew = height;
            _svgParent.setAttribute( 'height', _cntrlHeightNew + 'px' );
            _data.Height = _cntrlHeightNew;
        }
        if ( treeViewPortHeight > height ) {
            _cntrlHeightNew = treeViewPortHeight;
            _svgParent.setAttribute( 'height', _cntrlHeightNew + 'px' );
            _data.Height = _cntrlHeightNew;
        }
        _data.CtrlHeight = _ctrlHeight;
        _data.CtrlWidth = _cntrlWidthNew;

        _updateBgRects();
        _setForUpdate();
        _scrollCount = _nodeHandler.getScrollIndex();
        //Updating the scrollbars after updating the tree in case the scroll count is changed while updating the tree.
        _createVerticalScrollBar();
        _createHorizontalScrollBar();
        _createBCRects();
        if ( _data.URLPart.data.length > 0 ) {
            _calculateViewPortURLData();
        }
        // Only update the background rect adjacent to expand, collapse toolbar buttons on resize
        _createToolbarBackRect();
        if ( _createFilter ) {
            attributes = _getFilterComboBoxAttributes();
            _filterComboBox.show();
            _filterComboBox.update( attributes, _ctrlHeight, true );
        }
    };

    /*
    * Function to handle expandAll toolbar event
    * @function
    * @memberOf CPM.App
    */
    this.expandAll = function () {
        var
        selectedNode,
        paramIds = [0, 1],
        paramValues = [];
        if ( !_toolbar.isExpandAllEnabled() ) {//Do not do ExpandAll if the button is disabled.
            return;
        }
        if ( !_data.NodePart[0] ) {
            return;//Do not do ExpandAll if no data is available.
        }
        if ( _selectedNodeId && _selectedNodeId !== _data.NodePart[0].Id ) {
            selectedNode = _getNodeData( _selectedNodeId );
            paramValues = [12, _selectedNodeId];
        } else {
            selectedNode = _data.NodePart[0];
            paramValues = [12, ''];
        }
        if ( selectedNode.IsLeaf ) {
            return;//Do not do ExpandAll if a leaf node is selected.
        }
        if ( !_isExpandAll ) {//if not already expanded
            _isExpandAll = true;
            _isCollapseAll = false;
            WebCC.Events.fire( 'onExpandAll', _isExpandAll );
            selectedNode.IsFullyExpanded = true;
            if ( _prevNodeSelected ) {
                _tbUpdateRequired = true;
            } else {
                _updateToolbarButtons( selectedNode );
            }

            if ( _isFullDataPresent ) {
                if ( selectedNode.Id !== _data.NodePart[0].Id ) {
                    _expandAllChildren( selectedNode );
                    _isExpandAll = false;
                }
                _setBeforeTraverse();
                _setForUpdate();
                if ( !_isNodeInViewport( selectedNode.index ) ) {
                    _resetScrollCount( selectedNode );//If the selected node is outside the VP, reset the scroll index.
                }
                _createVerticalScrollBar();
                _createHorizontalScrollBar();
            } else {
                selectedNode.Children = [];
                if ( selectedNode.Id === _data.NodePart[0].Id ) {
                    _resetTree();
                    _isFullDataPresent = true;
                }
                WebCC.Extensions.HMI.DomainLogic.sendDLEvent( paramIds, paramValues );
            }
        }
        _alarmIconGrpCallback();
    };

    /*
    * Function to handle collapseAll toolbar event
    * @function
    * @memberOf CPM.App
    */
    this.collapseAll = function () {
        var
        selectedNode;
        if ( !_toolbar.isCollapseAllEnabled() ) {//Do not do CollapseAll if the button is disabled.
            return;
        }
        if ( !_data.NodePart[0] ) {
            return;//Do not do CollapseAll if no data is available.
        }
        if ( _selectedNodeId ) {
            selectedNode = _getNodeData( _selectedNodeId );
        } else {
            selectedNode = _data.NodePart[0];
        }
        if ( selectedNode.IsLeaf ) {
            return;//Do not do CollapseAll if a leaf node is selected.
        }
        if ( !_isCollapseAll ) {
            _isCollapseAll = true;
            _isExpandAll = false;
            WebCC.Events.fire( 'onCollapseAll', _isCollapseAll );
            selectedNode.IsFullyExpanded = false;
            if ( selectedNode.IsExpanded ) {
                this.toggleVisibility( selectedNode, true );
                if ( !_isNodeInViewport( selectedNode.index ) ) {
                    _resetScrollCount( selectedNode );//If the selected node is outside the VP, reset the scroll index.
                }
            } else {
                _isCollapseAll = false;
            }
            if ( !_prevNodeSelected || ( _prevNodeSelected && _selectedFilter !== _options['TBID_NONE'] ) ) { //Enable expandAll button if _prevNodeSelected is not available in the changed filter view (!'None') and collapseAll button is pressed 
                _updateToolbarButtons( selectedNode );
            }
        }
    };
    /*
    * Function to handle Filter toolbar event
    * @function 
    * @memberOf CPM.App
    */
    this.filter = function () {
        if ( _selectedFilter === _options['TBID_NODE_PENDINGALARMS'] ) {
            if ( !_data.NodePart[0] ) {
                return;
            }
            _resetTree();
            if ( ( Object.keys( _alarmData ).length === 0 ) || Object.keys( _alarmData.ActiveAlarms ).length === 0 ) {
                _data.URLPart.data = [];
                _data.URLPart.viewportData = [];
                _createBCRects();
                _count = 0;
                _linearDataArray = [];
                _toolbar.setExpandBtnOpacity( 0.5 );
                _toolbar.setCollapseBtnOpacity( 0.5 );
            } else {
                _setBeforeTraverse();
                _toolbar.setExpandBtnOpacity( 1 );
                _toolbar.setCollapseBtnOpacity( 1 );
            }
            _setForUpdate();
            _createVerticalScrollBar();
            _createHorizontalScrollBar();
            _alarmIconGrpCallback();
        }
        else if ( _selectedFilter === _options['TBID_NODE_VISUALIZATION'] ) {
            if ( Object.keys( _screenData ).length > 0 ) {
                self.handleScreenData();
            }
            else {
                //clearing the tree before requesting for screen window data
                _data.URLPart.data = [];
                _data.URLPart.viewportData = [];
                _createBCRects();               
                _count = 0;
                _linearDataArray = [];
                _toolbar.setExpandBtnOpacity( 0.5 );
                _toolbar.setCollapseBtnOpacity( 0.5 );
                _setForUpdate();
                _createVerticalScrollBar();
                _createHorizontalScrollBar();
                WebCC.Extensions.HMI.DomainLogic.sendDLEvent( [], [CPM.Enums.BrowsingMode.ScreenFilter] );
            }
        }
        else {
            if ( _data.NodePart[0] ) {
                _data.NodePart[0].IsExpanded = false;
                self.toggleVisibility( _data.NodePart[0] );
            }
        }

    };

    /*
    * Function to create new node in the tree
    * @function
    * @memberOf CPM.App
    * @params{node} node to be added to the tree
    */
    this.createNewNode = function ( node ) {
        var parentNode;
        if ( node.Parent === _data.NodePart[0].Name ) {
            parentNode = _data.NodePart[0];
        }
        else {
            parentNode = _searchForNode( _data.NodePart[0], node.Parent, _operation.add );
        }
        if ( parentNode ) {
            if ( parentNode.Children ) {
                parentNode.Children.push( node );
            }
            else {
                parentNode.Children = [];
                parentNode.Children.push( node );
            }
        }
        _count = 0;
        _deepestNodeWidth = 0;
        _deepestNode = 0;
        _traverse( _data.NodePart[0] );

    };

    /*
    * Function to load intial tree nodes whenever received from server
    * @function
    * @memberOf CPM.App
    * @params{rawData} data of the intial nodes to be displayed.
    */
    this.createHierarchyNode = function ( data ) {
        var node = _getDefaultNode();
        node.Name = data.Name;
        node.Id = data.Id;
        node.Children = data.Children;
        _data.NodePart.push( node );
        _count = 0;
        _deepestNodeWidth = 0;
        _deepestNode = 0;
        _updateParentDims();
    };

    /*
    * Function to load intial tree nodes whenever received from server
    * @function
    * @memberOf CPM.App
    * @params{rawData} data of the intial nodes to be displayed.
    */
    this.loadNodes = function ( rawData ) {
        var i = 0,
        data, selectedNode,
        parentNode;
        if ( !_nodeHeight ) {
            _getNodeDomHeight();
        }

        for ( i = 0; i < rawData.length; i++ ) {
            if ( _selectedNodeId ) {
                parentNode = _getNodeData( _selectedNodeId );
                if ( !parentNode.Children ) {
                    parentNode.Children = [];
                }
                parentNode.Children.push( _traverseRawdata( rawData[i] ) );
            }
            else {
                data = _data.NodePart[0] = _traverseRawdata( rawData[i] );
            }

        }
        if ( _isExpandAll && _selectedNodeId && _selectedNodeId !== _data.NodePart[0].Id ) {
            selectedNode = _getNodeData( _selectedNodeId );
            selectedNode.IsExpanded = true;//Since we add only child nodes in this case, we have to set the already available selected node 'expanded'.
            _isExpandAll = false;
        }

        _tbUpdateRequired = true;
        _setBeforeTraverse();
        _setForUpdate();
        if ( selectedNode && !_isNodeInViewport( selectedNode.index ) ) {
            _resetScrollCount( selectedNode );//If the selected node is outside the VP, reset the scroll index.
        }
        _updateParentDims();
        //Breadcrumb update required for scenario when the node selected from breadcrumb is not available with client but received from server in this function.
        if ( _isBCUpdateRequired ) {
            selectedNode = _getNodeData( _prevSelectedBCNodeId );
            selectedNode.isSelected = true;
            _prevNodeSelected.isSelected = false;
            _prevNodeSelected = selectedNode;
            _updateToolbarButtons( _prevNodeSelected );
            _updateURLData( selectedNode );
            WebCC.Properties.SelectedNode = selectedNode.fullPath;
            WebCC.Events.fire( 'onSelectionChanged', selectedNode.fullPath );
            _selectedNodeId = selectedNode.Id;
            _resetScrollCount( selectedNode );
            _isBCUpdateRequired = false;
        }
        _sendSummaryInfo();
        _addTifLibExpandoProps();
        if ( Object.keys( _screenData ).length === 0 && _selectedFilter && ( Object.keys( _options ).length > 0 && _selectedFilter === _options['TBID_NODE_VISUALIZATION'] ) ) { //Request explicitly to DL for the visualization data if the filter is configured as visualization
            self.filter();
        }
    };

    /*
    * Function to add new nodes to the existing tree nodes
    * @function
    * @memberOf CPM.App
    * @params{data} data of the new nodes to be added.
    * @params{isBufferData} Indicates if the data is to be stored in a buffer array or not.
    */
    this.addNewNodes = function ( data, isBufferData ) {
        var parentId = data.ParentId, parentNode, nodeData, formattedData;
        if ( isBufferData ) {
            _bufferDataArray.push( data );
            if ( !data.MoreFollows ) {
                for ( var i = 0; i < _bufferDataArray.length; i++ ) {
                    parentNode = _getNodeData( parentId );
                    if ( !parentNode.Children ) {
                        parentNode.Children = [];
                    }
                    nodeData = _bufferDataArray[i].DisplayData[0];
                    nodeData.ParentId = parentId;
                    nodeData.depth = parentNode.depth + 1;
                    formattedData = _traverseRawdata( nodeData );
                    parentNode.Children.push( formattedData );

                }
                _setBeforeTraverse();
                _createVerticalScrollBar();
                _nodeHandler.resetDataArray( _linearDataArray );
                _setForUpdate();
            }
        }
        else if ( parentId ) {
            parentNode = _getNodeData( parentId );
            if ( !parentNode.Children ) {
                parentNode.Children = [];
            }
            nodeData = data.DisplayData[0];
            nodeData.ParentId = parentId;
            nodeData.depth = parentNode.depth + 1;
            formattedData = _traverseRawdata( nodeData );
            parentNode.Children.push( formattedData );
            _setBeforeTraverse();
            _setForUpdate();
        }
        _alarmIconGrpCallback();
    };

    /*
    * Function to remove a node from the tree
    * @function
    * @memberOf CPM.App
    * @params{nodeName} name of the node to be removed.
    */
    this.removeNode = function ( nodeName ) {
        _searchForNode( _data.NodePart[0], nodeName, _operation.remove );
        _count = 0;
        _deepestNode = 0;
        _deepestNodeWidth = 0;
        _traverse( _data.NodePart[0] );
    };

    /*
    * Function to set the callback function.
    * @function
    * @memberOf CPM.App
    * @params{func} callback function name
    */
    this.setCallback = function ( func ) {
        _callback = func;
    };

    /*
    * Function to load the breadcrumb for the given node.
    * @function
    * @memberOf CPM.App
    * @params{data} selected node data
    */
    this.loadBreadCrumb = function ( data ) {
        var i = 0, crumbNode, maxNodeNameWidth = 0, cNodeNameWidth, crumbData = {},
        // extraPaddingGap = 48,
        length;
        _nodeDomHeight = _getNodeDomHeight();
        //holds children nodes of breadcrumb for a parent node
        _crumbChildren = [];
        //TODO: recheck if condition for expandable and non expandable node
        if ( data ) {
            length = data.length;
            if ( length !== 0 ) {
                for ( i = 0; i < length; i++ ) {
                    crumbNode = _getDefaultNode();
                    crumbNode.fullPath = data[i][2];
                    if ( _selectedFilter && _selectedFilter !== _options['TBID_NONE'] ) {
                        if ( _selectedFilter === _options['TBID_NODE_PENDINGALARMS'] && _alarmData ) {
                            if ( ( Object.keys( _alarmData.ActiveAlarms ).length > 0 || Object.keys( _alarmData.RemovedAlarms ).length > 0 ) ) {
                                if ( !( _alarmData.ActiveAlarms[crumbNode.fullPath] === 1 || _alarmData.RemovedAlarms[crumbNode.fullPath] === 0 ) ) {
                                    continue;
                                }
                            }
                        }
                        else if ( _selectedFilter === _options['TBID_NODE_VISUALIZATION'] && _screenData ) {
                            if ( ( Object.keys( _screenData.ScreenFilter ).length > 0 ) ) {
                                if ( _screenData.ScreenFilter[crumbNode.fullPath] !== 0 ) {
                                    continue;
                                }
                            }
                        }
                    }
                    crumbNode.Name = data[i][0];
                    crumbNode.Id = data[i][1];

                    crumbNode.bBox = _getTextBBox( crumbNode.Name );
                    crumbNode.isSelected = false;
                    if ( _prevSelectedBCNodeId && _prevSelectedBCNodeId === crumbNode.Id ) {
                        crumbNode.isSelected = true;
                        _prevSelectedCrumbNode = crumbNode;
                        _prevSelectedBCNodeId = crumbNode.Id;
                    }
                    _crumbNodeNameHeight = _getTextBBox( crumbNode.Name ).height;
                    cNodeNameWidth = _getTextBBox( crumbNode.Name ).width;
                    if ( maxNodeNameWidth < cNodeNameWidth ) {
                        maxNodeNameWidth = cNodeNameWidth;
                    }
                    _crumbNodeNameWidth = maxNodeNameWidth;
                    _crumbChildren.push( crumbNode );
                }
                if ( _crumbChildren.length > 0 ) {
                    _treeGroup.setAttribute( 'fill-opacity', '0.5' );
                }
                if ( ( _ctrlHeight - _nodeDomHeight - _toolbarHeight ) < ( _crumbChildren.length * _nodeDomHeight ) ) {
                    _createBCVerticalScrollBar();
                    if ( _isHorizontalScrollbarCreated ) {
                        _crumbHeight = _ctrlHeight - _toolbarHeight - CPM.Enums.Constants.urlHeight - _hScrollbarHeight;
                    } else {
                        _crumbHeight = _ctrlHeight - _toolbarHeight - CPM.Enums.Constants.urlHeight;
                    }
                } else {
                    _crumbHeight = _crumbChildren.length * _nodeDomHeight;
                }

                crumbData.crumbX = _crumbX;
                crumbData.crumbNodeNameWidth = _crumbNodeNameWidth;
                crumbData.crumbHeight = _crumbHeight;
                crumbData.white = _data.white;
                crumbData.grey3 = _data.grey3;
                crumbData.crumbNodeNameHeight = _crumbNodeNameHeight;
                crumbData.SelectionForeColor = _data.SelectionForeColor;
                crumbData.active = _data.active;
                _breadCrumb.createBreadCrumb( _crumbChildren, crumbData, _toolbarHeight );

                _breadcrumbGroup = document.getElementById( 'breadcrumbGroup' );
                _breadcrumbGroupMatrix = _breadcrumbGroup.transform.baseVal.getItem( 0 ).matrix;
            }
        }
    };

    /*
    * Function to handle alarm summary data
    * @function
    * @memberOf CPM.App
    * @params{data} alarm summary data
    */
    this.handleAlarmData = function ( data ) {
        var selectedNode, y;
        if ( ( data.ActiveAlarms && data.ActiveAlarms !== null ) || ( data.RemovedAlarms && data.RemovedAlarms !== null ) ) {
            _alarmData = data;
            if ( _selectedFilter === _options.TBID_NODE_PENDINGALARMS ) {
                if ( Object.keys( data.ActiveAlarms ).length === 0 ) {
                    _resetTree();
                    _data.URLPart.data = [];
                    _data.URLPart.viewportData = [];
                    _createBCRects();
                    _count = 0;
                    _linearDataArray = [];
                    _toolbar.setExpandBtnOpacity( 0.5 );
                    _toolbar.setCollapseBtnOpacity( 0.5 );
                } else {
                    if ( Object.keys( data.RemovedAlarms ).length > 0 ) {
                        if ( _selectedNodeId ) {
                            selectedNode = _getNodeData( _selectedNodeId );
                            if ( data.RemovedAlarms[selectedNode.fullPath] === 0 ) {
                                selectedNode.isSelected = false;
                                _nodeHandler.setSelectedNode( selectedNode );
                                _selectedNodeId = undefined;
                            }
                        }
                    }
                    _setBeforeTraverse();
                    _toolbar.setExpandBtnOpacity( 1 );
                    _toolbar.setCollapseBtnOpacity( 1 );
                }
                _setForUpdate( data );
                _createVerticalScrollBar();
                _createHorizontalScrollBar();
            }
            else {

                // horizontal scrollbar not present, alarm raised
                _nodeHandler.updateAlarmSummary( data );      // Called on screen load if alarm is raised

                // horizontal scrollbar present 
                if ( _data.Width < _deepestNodeWidth ) {
                    y = _toolbarHeight + CPM.Enums.Constants.urlHeight;
                    // alarm raised 
                    if ( _alarmData.ActiveAlarms && Object.keys( _alarmData.ActiveAlarms ).length > 0 ) {
                        _deepestNodeWidth = _deepestNodeWidth + CPM.Enums.Constants.alarmIconToTextGap;
                    }
                        // alarm removed
                    else if ( _alarmData.RemovedAlarms && Object.keys( _alarmData.RemovedAlarms ).length > 0 ) {
                        // multiplied by a factor of 2 because when 0 is entered in I/O field Active alarms are still present and above if condition is called.
                        // Only on acknowledging, alarm is removed and comes to this condition. Alarm icon width is also considered
                        _deepestNodeWidth = _deepestNodeWidth - 2 * ( CPM.Enums.Constants.alarmIconToTextGap + CPM.Enums.Constants.alarmIconWidth );
                    }
                    _nodeHandler.updateAlarmIconGrp( _deepestNodeWidth, y );
                    _createHorizontalScrollBar();
                }
            }
        }
    };

    /*
    * Function to handle screen window data
    * @function
    * @memberOf CPM.App
    * @params{data} screen window data
    */
    this.handleScreenData = function ( data ) {
        var selectedNode;
        if ( data && data.ScreenFilter !== null ) {
            _screenData = data;    
        }
        if ( _selectedFilter !== _options['TBID_NONE'] ) {
            if ( Object.keys( _screenData.ScreenFilter ).length === 0 ) {
                _resetTree();
                _data.URLPart.data = [];
                _data.URLPart.viewportData = [];
                _createBCRects();
                _count = 0;
                _linearDataArray = [];
                _toolbar.setExpandBtnOpacity( 0.5 );
                _toolbar.setCollapseBtnOpacity( 0.5 );
            } else {
                if ( _selectedNodeId ) {
                    selectedNode = _getNodeData( _selectedNodeId );
                    if ( _screenData.ScreenFilter[selectedNode.fullPath] !== 0 ) {
                        selectedNode.isSelected = false;
                        _nodeHandler.setSelectedNode( selectedNode );
                        _selectedNodeId = undefined;
                    }
                }
                _setBeforeTraverse();
                _toolbar.setCollapseBtnOpacity( 1 );
            }            
            _setForUpdate();
            _createVerticalScrollBar();
            _createHorizontalScrollBar();
        }    
    };

    /*
    * Function to handle runtime language change event
    * @function
    * @memberOf CPM.App
    * @params{data} language id
    */
    this.handleLanguageChange = function ( languageId ) {
        var selectedFilterIndex, key, attributes = {};
        WebCC.Extensions.X_Textbib.setLocale( languageId );

        if ( _createFilter ) {
            for ( key in _options ) {
                if ( _options[key] === _selectedFilter ) {
                    selectedFilterIndex = key;
                    break;
                }
            }
            _options['TBID_NONE'] = WebCC.Extensions.X_Textbib.getText( 'TBID_NONE' );
            if ( _alarmComapnion ) {
                _options['TBID_NODE_PENDINGALARMS'] = WebCC.Extensions.X_Textbib.getText( 'TBID_NODE_PENDINGALARMS' );
            }
            if ( _screenWindowCompanion ) {
                _options['TBID_NODE_VISUALIZATION'] = WebCC.Extensions.X_Textbib.getText( 'TBID_NODE_VISUALIZATION' );
            }

            if ( _filterComboBox ) {
                _filterComboBox.setOptions( _getValues( _options ) );
                _comboMaxWidth = _filterComboBox.getMaxWidth();//Max width of combobox will change and has to be calculated again when language changes.
                _selectedFilter = _options[selectedFilterIndex];
                attributes = _getFilterComboBoxAttributes();//Update the combobox dimensions as per the new _comboMaxWidth value.
                _filterComboBox.update( attributes, _ctrlHeight, false );
                _filterComboBox.setSelectedOption( _selectedFilter );
            }
        }
    };

    /*
    * Function to disable the toolbar buttons
    * @function
    * @memberOf CPM.App
    */
    this.disableToolbarButtons = function () {
        _toolbar.setExpandBtnOpacity( 0.5 );
        _toolbar.setCollapseBtnOpacity( 0.5 );
    };

    /*
    * Function to update the CPM control properties
    * @function
    * @memberOf CPM.App
    * @params{data} holds the property name and its value
    */
    this.updateProperties = function ( data ) {
        var node;
        switch ( data.key ) {
            case 'SelectedNode':
                _selectedNodePath = data.value;
                node = _getNodeDataByPath( _selectedNodePath );
                if ( node ) {
                    if ( _prevNodeSelected && _prevNodeSelected.fullPath === _selectedNodePath ) {
                        return;
                    }
                    _setSelected( node, false );
                    _resetScrollCount( node );
                }
                break;
            case 'SelectionBackColor':
                _data.SelectionBackColor = data.value ? _toRGBA( data.value ) : _data.SelectionBackColor;
                _data.active = _data.SelectionBackColor;
                _nodeHandler.updateSelectionColor( _data.active );
                break;
            case 'SelectionForeColor':
                _data.SelectionForeColor = data.value ? _toRGBA( data.value ) : _data.SelectionForeColor;
                _nodeHandler.updateSelectionForeColor( _data.SelectionForeColor );
                break;
            case 'Enabled':
                _data.Enabled = data.value;
                if ( _data.Enabled ) {
                    _toolbar.setExpandBtnOpacity( 1 );
                    _toolbar.setCollapseBtnOpacity( 1 );
                } else {
                    _toolbar.setExpandBtnOpacity( 0.5 );
                    _toolbar.setCollapseBtnOpacity( 0.5 );
                }
                break;
            case 'Filter':
                if ( _createFilter ) {
                    switch ( data.value ) {
                        case CPM.Enums.Filter.NodeWithPendingAlarms:
                            WebCC.Properties.Filter = data.value;
                            _selectedFilter = _options['TBID_NODE_PENDINGALARMS'];
                            break;
                        case CPM.Enums.Filter.NodeWithVisualization:
                            WebCC.Properties.Filter = data.value;
                            _selectedFilter = _options['TBID_NODE_VISUALIZATION'];
                            break;
                        case CPM.Enums.Filter.None:
                            WebCC.Properties.Filter = data.value;
                            _selectedFilter = _options['TBID_NONE'];
                            break;
                        default:
                            break;
                    }
                    _filterComboBox.setSelectedOption( _selectedFilter );
                    self.filter();
                }
                break;
            default:
                break;
        }
    };
};
